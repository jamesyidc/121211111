# 27币1分钟涨跌幅追踪系统

## 📊 系统简介

27币涨跌幅追踪系统是一个实时追踪主流加密货币涨跌幅的自动化系统。

### 核心功能
- **实时追踪**: 每1分钟自动采集27个主流币种的价格变化
- **涨跌幅计算**: 相对当天0点基准价计算涨跌幅并求和
- **数据存储**: JSONL格式存储，每天一个文件
- **可视化展示**: 实时图表展示涨跌幅趋势

### 追踪的27个币种
```
BTC, ETH, XRP, BNB, SOL, LTC, DOGE, SUI, TRX, TON,
ETC, BCH, HBAR, XLM, FIL, LINK, CRO, DOT, AAVE, UNI,
NEAR, APT, CFX, CRV, STX, LDO, TAO
```

---

## 📁 文件结构

```
27币1分钟涨跌幅追踪/
├── README.md                           # 本文档
├── DEPLOY.md                           # 部署说明
├── coin_change_tracker.py              # Python采集器
├── coin_change_tracker.html            # 前端页面
├── coin_change_routes.txt              # Flask API路由代码
├── pm2_config.json                     # PM2配置文件
├── data/                               # 数据目录
│   ├── coin_change_20260124.jsonl     # 今天的数据
│   ├── coin_change_20260123.jsonl     # 昨天的数据
│   ├── coin_change_20260122.jsonl     # 前天的数据
│   ├── baseline_20260124.json         # 今天的基准价
│   ├── baseline_20260123.json         # 昨天的基准价
│   └── baseline_20260122.json         # 前天的基准价
└── COIN_CHANGE_JSONL_REPORT.md        # 系统验证报告
```

---

## 🚀 快速开始

### 1. 解压文件
```bash
tar -xzf 27币1分钟涨跌幅追踪.tar.gz
cd 27币1分钟涨跌幅追踪/
```

### 2. 安装依赖
```bash
pip install requests flask
```

### 3. 启动采集器
```bash
# 方式1: 直接运行
python3 coin_change_tracker.py

# 方式2: 使用 PM2 管理（推荐）
pm2 start coin_change_tracker.py --name coin-change-tracker --interpreter python3
pm2 save
```

### 4. 配置 Flask 路由
将 `coin_change_routes.txt` 中的代码添加到你的 Flask 应用中。

### 5. 访问前端
```
http://your-server:5000/coin-change-tracker
```

---

## 📡 API 端点

### 1. 获取最新数据
```bash
GET /api/coin-change-tracker/latest
```

**响应示例**:
```json
{
    "success": true,
    "data": {
        "timestamp": "2026-01-24T17:09:10.866703+08:00",
        "total_change": -14.03,
        "valid_count": 27,
        "time": "17:09:10",
        "changes": {
            "BTC-USDT-SWAP": {
                "baseline_price": 89703.7,
                "current_price": 89577.8,
                "change_pct": -0.14
            }
        }
    }
}
```

### 2. 获取历史数据
```bash
GET /api/coin-change-tracker/history?date=20260124&limit=100
```

**参数**:
- `date`: 日期（YYYYMMDD格式）
- `limit`: 返回数量限制（默认1440）

### 3. 获取基准价
```bash
GET /api/coin-change-tracker/baseline
```

### 4. 重置基准价
```bash
POST /api/coin-change-tracker/reset-baseline
```

---

## 🔧 配置说明

### 数据目录
采集器会自动创建 `data/coin_change_tracker/` 目录存储数据。

**数据文件命名规则**:
- 追踪数据: `coin_change_YYYYMMDD.jsonl`
- 基准价: `baseline_YYYYMMDD.json`

### 基准价设置
- **来源**: OKX日线开盘价（代表当天0点价格）
- **重置时间**: 每天0点自动重置
- **获取方式**: 从OKX API获取日线K线数据

### 采集周期
- **周期**: 1分钟
- **触发时间**: 每分钟的0秒
- **等待策略**: 采集完成后等待到下一分钟

---

## 📊 数据格式

### JSONL 记录格式
每条记录一行，JSON格式：

```json
{
    "timestamp": "2026-01-24T17:09:10.866703+08:00",
    "timestamp_unix": 1769245750,
    "date": "20260124",
    "time": "17:09:10",
    "baseline_date": "20260124",
    "total_change": -14.03,
    "valid_count": 27,
    "changes": {
        "BTC-USDT-SWAP": {
            "baseline_price": 89703.7,
            "current_price": 89577.8,
            "change_pct": -0.14
        }
    }
}
```

### 字段说明
- `timestamp`: ISO 8601格式时间戳（带时区）
- `timestamp_unix`: Unix时间戳
- `date`: 日期（YYYYMMDD）
- `time`: 时间（HH:MM:SS）
- `baseline_date`: 基准价日期
- `total_change`: 27币涨跌幅总和（%）
- `valid_count`: 有效币种数量
- `changes`: 每个币种的详细数据
  - `baseline_price`: 基准价（当天0点价格）
  - `current_price`: 当前价格
  - `change_pct`: 涨跌幅（%）

---

## 🛠️ 维护操作

### 查看运行日志
```bash
pm2 logs coin-change-tracker
```

### 重启采集器
```bash
pm2 restart coin-change-tracker
```

### 停止采集器
```bash
pm2 stop coin-change-tracker
```

### 查看进程状态
```bash
pm2 status
```

### 数据备份
```bash
# 备份数据目录
tar -czf coin_change_backup_$(date +%Y%m%d).tar.gz data/coin_change_tracker/
```

### 数据清理
```bash
# 删除30天前的数据
find data/coin_change_tracker/ -name "*.jsonl" -mtime +30 -delete
find data/coin_change_tracker/ -name "baseline_*.json" -mtime +30 -delete
```

---

## 📈 性能指标

- **采集成功率**: 100% (27/27币种)
- **单次采集耗时**: ~3-5秒
- **数据文件大小**: ~3-4MB/天（1440条记录）
- **内存占用**: ~8-10MB（PM2进程）
- **CPU占用**: 忽略不计（1分钟采集一次）

---

## ⚠️ 注意事项

### 1. API访问限制
- 使用OKX公开API，注意访问频率限制
- 每个币种间隔0.1秒，避免请求过快

### 2. 数据完整性
- 采集器异常时会自动重试
- 建议使用PM2管理，确保自动重启
- 定期备份数据目录

### 3. 时区设置
- 系统使用北京时间（UTC+8）
- 基准价重置时间：北京时间每天0点

### 4. 存储空间
- 每天约3-4MB数据
- 建议保留至少30天的历史数据
- 定期清理过期数据

---

## 🔗 相关链接

- **OKX API文档**: https://www.okx.com/docs-v5/
- **PM2文档**: https://pm2.keymetrics.io/
- **Flask文档**: https://flask.palletsprojects.com/

---

## 📝 版本历史

### v1.0.0 (2026-01-24)
- ✅ 初始版本发布
- ✅ 支持27个币种追踪
- ✅ JSONL数据格式
- ✅ PM2进程管理
- ✅ 实时图表展示

---

## 📞 技术支持

如有问题，请查看以下文档：
- `COIN_CHANGE_JSONL_REPORT.md` - 系统验证报告
- `DEPLOY.md` - 详细部署说明

---

**打包时间**: 2026-01-24 17:20 北京时间  
**系统版本**: v1.0.0  
**数据格式**: JSONL  
**打包内容**: 完整系统（代码+数据+配置）
