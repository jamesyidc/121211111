# 27币1分钟涨跌幅追踪系统 - 部署说明

## 📋 目录
1. [系统要求](#系统要求)
2. [安装步骤](#安装步骤)
3. [配置Flask路由](#配置flask路由)
4. [启动服务](#启动服务)
5. [验证安装](#验证安装)
6. [常见问题](#常见问题)

---

## 系统要求

### 软件依赖
- **Python**: 3.8+
- **pip**: 最新版本
- **PM2**: 全局安装（可选，推荐）

### Python包依赖
```bash
pip install requests flask
```

### 可选工具
```bash
# PM2 进程管理器（推荐）
npm install -g pm2

# 或者使用 supervisor
pip install supervisor
```

---

## 安装步骤

### 1. 解压文件包
```bash
# 解压到指定目录
cd /your/project/path
tar -xzf 27币1分钟涨跌幅追踪.tar.gz

# 查看文件结构
ls -la 27币1分钟涨跌幅追踪/
```

### 2. 创建目录结构
```bash
cd 27币1分钟涨跌幅追踪/

# 创建日志目录（如果不存在）
mkdir -p logs

# 验证数据目录
ls -lh data/
```

### 3. 安装Python依赖
```bash
pip install requests flask
```

### 4. 测试采集器
```bash
# 单次运行测试
python3 coin_change_tracker.py

# 应该看到类似输出：
# ✅ 27币涨跌幅追踪系统初始化完成
# 📁 数据目录: /path/to/data/coin_change_tracker
# 📊 追踪币种数: 27
```

---

## 配置Flask路由

### 方式1: 复制路由代码

1. 打开 `coin_change_routes.txt`
2. 将所有路由代码复制到你的 Flask 应用（通常是 `app.py` 或 `app_new.py`）

**插入位置建议**:
```python
# 在 Flask app 初始化之后
app = Flask(__name__)

# ... 其他路由 ...

# ========== 27币涨跌幅追踪系统路由 ==========
# 这里粘贴 coin_change_routes.txt 的内容

@app.route('/coin-change-tracker')
def coin_change_tracker():
    """27币涨跌幅追踪系统主页"""
    from flask import render_template, make_response
    response = make_response(render_template('coin_change_tracker.html'))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/api/coin-change-tracker/latest', methods=['GET'])
def get_coin_change_latest():
    # ... API 代码 ...
    pass

# ... 其他 API 路由 ...
```

### 方式2: 使用Blueprint（推荐）

创建独立的蓝图文件：

```python
# coin_change_blueprint.py
from flask import Blueprint, jsonify, request, render_template, make_response
import json
from pathlib import Path
from datetime import datetime, timezone, timedelta

coin_change_bp = Blueprint('coin_change', __name__)

@coin_change_bp.route('/coin-change-tracker')
def coin_change_tracker():
    """27币涨跌幅追踪系统主页"""
    response = make_response(render_template('coin_change_tracker.html'))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

# ... 复制其他路由 ...
```

然后在主应用中注册：
```python
from coin_change_blueprint import coin_change_bp
app.register_blueprint(coin_change_bp)
```

### 3. 复制HTML模板

```bash
# 复制模板文件到 Flask 的 templates 目录
cp coin_change_tracker.html /path/to/your/flask/templates/
```

---

## 启动服务

### 方式1: 使用PM2（推荐）

```bash
# 启动采集器
pm2 start coin_change_tracker.py \
    --name coin-change-tracker \
    --interpreter python3 \
    --log logs/coin_change_tracker.log

# 查看状态
pm2 status

# 查看日志
pm2 logs coin-change-tracker

# 保存配置（开机自启）
pm2 save
pm2 startup
```

### 方式2: 使用systemd

创建服务文件：
```bash
sudo nano /etc/systemd/system/coin-change-tracker.service
```

内容：
```ini
[Unit]
Description=27币涨跌幅追踪系统
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/27币1分钟涨跌幅追踪
ExecStart=/usr/bin/python3 coin_change_tracker.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

启动服务：
```bash
sudo systemctl daemon-reload
sudo systemctl start coin-change-tracker
sudo systemctl enable coin-change-tracker
sudo systemctl status coin-change-tracker
```

### 方式3: 使用nohup

```bash
nohup python3 coin_change_tracker.py > logs/coin_change_tracker.log 2>&1 &
echo $! > coin_change_tracker.pid
```

---

## 验证安装

### 1. 检查采集器运行状态

**PM2方式**:
```bash
pm2 status coin-change-tracker
# 应该显示 status: online
```

**系统进程**:
```bash
ps aux | grep coin_change_tracker
```

### 2. 检查数据文件

```bash
# 查看今天的数据文件
ls -lh data/coin_change_tracker/coin_change_$(date +%Y%m%d).jsonl

# 查看最后几条记录
tail -3 data/coin_change_tracker/coin_change_$(date +%Y%m%d).jsonl | python3 -m json.tool
```

### 3. 测试API端点

```bash
# 测试最新数据API
curl http://localhost:5000/api/coin-change-tracker/latest | python3 -m json.tool

# 应该返回类似：
# {
#     "success": true,
#     "data": {
#         "timestamp": "2026-01-24T17:09:10.866703+08:00",
#         "total_change": -14.03,
#         "valid_count": 27,
#         ...
#     }
# }
```

### 4. 访问前端页面

打开浏览器访问：
```
http://your-server:5000/coin-change-tracker
```

应该看到：
- ✅ 实时涨跌幅总和
- ✅ 27个币种的详细数据
- ✅ 实时更新的图表

---

## 常见问题

### Q1: 采集器启动失败

**问题**: `ModuleNotFoundError: No module named 'requests'`

**解决**:
```bash
pip install requests
```

---

### Q2: 无法获取OKX数据

**问题**: `❌ 获取行情失败: {"code":"51000","msg":"Error"}`

**可能原因**:
1. 网络连接问题
2. OKX API临时不可用
3. 请求过于频繁

**解决**:
```bash
# 检查网络连接
curl https://www.okx.com

# 重启采集器
pm2 restart coin-change-tracker
```

---

### Q3: 数据文件不存在

**问题**: `FileNotFoundError: [Errno 2] No such file or directory: 'data/coin_change_tracker/...'`

**解决**:
```bash
# 确保数据目录存在
mkdir -p data/coin_change_tracker

# 检查目录权限
chmod 755 data/coin_change_tracker
```

---

### Q4: API返回404错误

**问题**: 访问 `/api/coin-change-tracker/latest` 返回404

**可能原因**:
1. Flask路由未正确配置
2. 模板文件路径错误

**解决**:
1. 检查路由代码是否正确添加
2. 重启Flask应用
3. 查看Flask日志

---

### Q5: PM2进程频繁重启

**问题**: `pm2 status` 显示 restart 次数很多

**解决**:
```bash
# 查看错误日志
pm2 logs coin-change-tracker --lines 50

# 检查Python版本
python3 --version

# 确保依赖已安装
pip install requests
```

---

### Q6: 基准价获取失败

**问题**: `❌ 获取日线开盘价失败，使用当前价格作为临时基准`

**说明**: 
- 这是正常的回退机制
- 会使用当前价格作为临时基准
- 不影响后续运行

**优化**:
```bash
# 手动重置基准价
curl -X POST http://localhost:5000/api/coin-change-tracker/reset-baseline
```

---

## 🔧 高级配置

### 自定义数据目录

修改 `coin_change_tracker.py` 第27行：
```python
# 原来
self.data_dir = PROJECT_ROOT / 'data' / 'coin_change_tracker'

# 修改为自定义路径
self.data_dir = Path('/your/custom/path/coin_change_tracker')
```

### 修改采集周期

修改 `coin_change_tracker.py` 第336行：
```python
# 原来：1分钟
time.sleep(sleep_seconds)

# 修改为5分钟
time.sleep(300)  # 5分钟 = 300秒
```

### 增减追踪币种

修改 `coin_change_tracker.py` 第31-41行的 `self.symbols` 列表。

---

## 📊 性能优化建议

### 1. 数据压缩

```bash
# 定期压缩旧数据
gzip data/coin_change_tracker/coin_change_20260101.jsonl
```

### 2. 数据归档

```bash
# 按月归档
tar -czf archive_202601.tar.gz data/coin_change_tracker/coin_change_202601*.jsonl
```

### 3. 日志轮转

PM2自动处理，或使用logrotate：
```bash
# /etc/logrotate.d/coin-change-tracker
/path/to/logs/coin_change_tracker.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
}
```

---

## 📞 获取帮助

如遇到问题：
1. 查看日志: `pm2 logs coin-change-tracker`
2. 检查数据: `tail -f data/coin_change_tracker/coin_change_$(date +%Y%m%d).jsonl`
3. 阅读文档: `README.md` 和 `COIN_CHANGE_JSONL_REPORT.md`

---

**部署文档版本**: v1.0.0  
**最后更新**: 2026-01-24 17:20 北京时间
